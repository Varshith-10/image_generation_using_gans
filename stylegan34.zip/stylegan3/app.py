import os
import io
import streamlit as st
import torch
import numpy as np
import PIL.Image
import dnnlib
import legacy

def make_transform(translate, angle):
    m = np.eye(3)
    s = np.sin(angle/360.0*np.pi*2)
    c = np.cos(angle/360.0*np.pi*2)
    m[0][0] = c
    m[0][1] = s
    m[0][2] = translate[0]
    m[1][0] = -s
    m[1][1] = c
    m[1][2] = translate[1]
    return m

def generate_image(G, device, seed, truncation_psi, translate, rotate):
    """Helper function to generate a single image"""
    try:
        z = torch.from_numpy(np.random.RandomState(seed).randn(1, G.z_dim)).to(device)
        label = torch.zeros([1, G.c_dim], device=device)
        
        # Handle translation and rotation
        if hasattr(G.synthesis, 'input'):
            m = make_transform(translate, rotate)
            m = np.linalg.inv(m)
            G.synthesis.input.transform.copy_(torch.from_numpy(m))
        
        # Generate image
        img = G(z, label, truncation_psi=truncation_psi, noise_mode='const')
        img = (img.permute(0, 2, 3, 1) * 127.5 + 128).clamp(0, 255).to(torch.uint8)[0].cpu().numpy()
        return PIL.Image.fromarray(img, 'RGB')
    except Exception as e:
        st.error(f"Error generating image for seed {seed}: {str(e)}")
        return None

def main():
    st.set_page_config(page_title="StyleGAN3 Generator", layout="wide")
    st.title("StyleGAN3 Image Generator")
    
    # Default model URLs
    model_urls = {
        "FFHQ": "https://api.ngc.nvidia.com/v2/models/nvidia/research/stylegan3/versions/1/files/stylegan3-r-ffhq-1024x1024.pkl",
        "AFHQv2": "https://api.ngc.nvidia.com/v2/models/nvidia/research/stylegan3/versions/1/files/stylegan3-r-afhqv2-512x512.pkl",
        "MetFaces-U": "https://api.ngc.nvidia.com/v2/models/nvidia/research/stylegan3/versions/1/files/stylegan3-t-metfacesu-1024x1024.pkl"
    }
    
    # Sidebar controls
    st.sidebar.header("Settings")
    
    # Model selection
    selected_model = st.sidebar.selectbox("Select Model", list(model_urls.keys()))
    network_pkl = model_urls[selected_model]
    
    # Seed input
    seed_input = st.sidebar.text_input("Enter seeds (comma-separated)", "0,1,2")
    seeds = [int(s.strip()) for s in seed_input.split(",") if s.strip().isdigit()]
    
    # Additional parameters
    truncation_psi = st.sidebar.slider("Truncation Psi", 0.0, 2.0, 1.0)
    translate_x = st.sidebar.slider("Translate X", -1.0, 1.0, 0.0)
    translate_y = st.sidebar.slider("Translate Y", -1.0, 1.0, 0.0)
    rotate_angle = st.sidebar.slider("Rotation Angle", -180.0, 180.0, 0.0)
    
    # Add status placeholder for messages
    status = st.empty()
    
    try:
        # Load the network only once and cache it
        @st.cache_resource
        def load_network(pkl):
            status.text("Loading network...")
            device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            with dnnlib.util.open_url(pkl) as f:
                G = legacy.load_network_pkl(f)['G_ema'].to(device)
            return G, device

        # Generate button
        if st.sidebar.button("Generate Images"):
            if len(seeds) > 0:
                try:
                    G, device = load_network(network_pkl)
                    status.text(f"Generating {len(seeds)} images...")
                    
                    # Create columns for displaying images
                    cols = st.columns(3)  # Always use 3 columns
                    
                    # Generate and display images
                    for idx, seed in enumerate(seeds):
                        col_idx = idx % 3
                        with cols[col_idx]:
                            with st.spinner(f"Generating seed {seed}"):
                                img = generate_image(
                                    G, device, seed, 
                                    truncation_psi,
                                    (translate_x, translate_y),
                                    rotate_angle
                                )
                                if img is not None:
                                    # Convert PIL image to bytes for display
                                    buf = io.BytesIO()
                                    img.save(buf, format='PNG')
                                    st.image(buf, caption=f'Seed {seed}')
                                    
                    status.text("Generation complete!")
                    
                except Exception as e:
                    st.error(f"Error during generation: {str(e)}")
            else:
                st.error("Please enter at least one valid seed number")
    
    except Exception as e:
        st.error(f"Application error: {str(e)}")

if __name__ == "__main__":
    main()